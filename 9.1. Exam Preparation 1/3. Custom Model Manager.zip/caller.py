import os
import django


# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Director, Actor, Movie

# For Exercise 3, we call the function over the Director class, not through an instance
# print(Director.objects.get_directors_by_movies_count().last().__dict__)