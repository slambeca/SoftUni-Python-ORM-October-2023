from django.contrib import admin

from main_app.models import Director, Actor, Movie


@admin.register(Director)
class DirectorAdmin(admin.ModelAdmin):
    # Specify the fields to be displayed in the list view of the admin site
    list_display = ["full_name", "birth_date", "nationality"]
    # Add a filter for 'years_of_experience' in the admin site
    list_filter = ["years_of_experience"]
    # Enable search by 'full_name' and 'nationality' in the admin site
    search_fields = ["full_name", "nationality"]
    search_help_text = "Search by Full Name and Nationality"


@admin.register(Actor)
class ActorAdmin(admin.ModelAdmin):
    list_display = ["full_name", "birth_date", "nationality"]
    list_filter = ["is_awarded"]
    search_fields = ["full_name"]
    readonly_fields = ["last_updated"]
    search_help_text = "Search by Full Name"


@admin.register(Movie)
class MovieAdmin(admin.ModelAdmin):
    list_display = ["title", "storyline", "rating", "director"]
    list_filter = ["is_awarded", "is_classic", "genre"]
    # Enable search by 'title' and director’s 'full_name' (searching movies by director's full name)
    search_fields = ["title", "director__full_name"]
    readonly_fields = ["last_updated"]
    search_help_text = "Search by Title and Director's Full Name"

# python manage.py createsuperuser
# python manage.py runserver