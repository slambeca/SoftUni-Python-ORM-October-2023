import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Director, Actor, Movie
from django.db.models import Q, F, Count, Avg


# For Exercise 3, we call the function over the Director class, not through an instance
# print(Director.objects.get_directors_by_movies_count().last().__dict__)


# def insert_data():  # Create a function for data population
#     # director1 = Director(**kwargs)
#     # director1.save()
#     director1 = Director.objects.get(full_name="Francis Ford Coppola", years_of_experience=50)
#     director2 = Director.objects.get(full_name="Akira Kurosawa", years_of_experience=0)
#     director3 = Director.objects.get(full_name="Martin Scorsese", nationality="American and Italian",
#                                      years_of_experience=60)
#
#     actor1 = Actor.objects.get(full_name="Al Pacino")
#     actor2 = Actor.objects.get(full_name="Robert Duvall")
#     actor3 = Actor.objects.get(full_name="Joaquin Phoenix")
#
#     movie1 = Movie.objects.create(title="The Godfather", rating=9.9, starring_actor=actor1, director=director3,
#                                   release_date="1972-01-01")
#     movie1.actors.add(actor1)
#     movie1.actors.add(actor2)
#
#     movie2 = Movie.objects.create(title="Apocalypse Now", rating=9.5, starring_actor=actor1, director=director1,
#                                   release_date="1972-01-01")
#     movie2.actors.add(actor1)    # We use add on ManyToMany field
#
#
# insert_data()

def get_directors(search_name=None, search_nationality=None):
    if search_name is None and search_nationality is None:
        return ""

    query = Q()  # It is better practice to define the Q() object before the if-elif clauses, not only in them
    query_name = Q(full_name__icontains=search_name)
    query_nationality = Q(nationality__icontains=search_nationality)

    if search_name and search_nationality:
        query = query_name & query_nationality
    elif search_name and not search_nationality:
        query = query_name
    elif not search_name and search_nationality:
        query = query_nationality

    directors = Director.objects.filter(query).order_by("full_name")

    if not directors:
        return ""

    result = []

    for director in directors:
        result.append(f"Director: {director.full_name}, "
                      f"nationality: {director.nationality}, "
                      f"experience: {director.years_of_experience}")

    return "\n".join(result)


# print(get_directors("martin"))


def get_top_director():
    director = Director.objects.get_directors_by_movies_count().first()

    if not director:
        return ""

    return f"Top Director: {director.full_name}, movies: {director.count_movies}."


# print(get_top_directors())


def get_top_actor():
    actor = Actor.objects.prefetch_related('starring_actor_movies') \
        .annotate(
        num_of_movies=Count('starring_actor_movies'),
        movies_avg_rating=Avg('starring_actor_movies__rating')) \
        .order_by('-num_of_movies', 'full_name') \
        .first()

    if not actor or not actor.num_of_movies:
        return ""

    movies = ", ".join(movie.title for movie in actor.starring_actor_movies.all())

    return f"Top Actor: {actor.full_name}, starring in movies: {movies}, " \
           f"movies average rating: {actor.movies_avg_rating:.1f}"


# print(get_top_actor())


def get_actors_by_movies_count():    # Always copy the name of the function!
    actors = Actor.objects.annotate(num_movies=Count("actors_movies")).order_by("-num_movies", "full_name")[:3]

    if not actors or not actors[0].num_movies:    # If the first doesn't have movies, the others also don't have
        # works with if not actors or not Movie.objects.all() to check if we have movies
        return ""

    result = []

    for actor in actors:
        result.append(f"{actor.full_name}, participated in {actor.num_movies} movies")

    return "\n".join(result)


# print(get_actors_by_movies_count())

def get_top_rated_awarded_movie():
    movie = Movie.objects.filter(is_awarded=True).order_by("-rating", "title").first()

    if not movie:
        return ""

    starring_actor = movie.starring_actor.full_name if movie.starring_actor else "N/A"
    cast = ", ".join([actor.full_name for actor in movie.actors.all().order_by("full_name")])

    return (f"Top rated awarded movie: {movie.title}, rating: {movie.rating:.1f}. Starring actor: "
            f"{starring_actor}. Cast: {cast}.")


# print(get_top_rated_awarded_movie())


def increase_rating():
    movies_to_update = Movie.objects.filter(is_classic=True, rating__lt=10)

    if not movies_to_update:
        return "No ratings increased."

    updated_movies = movies_to_update.update(rating=F("rating") + 0.1)    # Returns integer

    return f"Rating increased for {updated_movies} movies."


print(increase_rating())