from django.db import models


class DirectorManager(models.Manager):
    def get_directors_by_movies_count(self):
        return self.annotate(count_movies=models.Count("director_movies")).order_by("-count_movies", "full_name")
    # We are using the reverse relationship with the related_name "director_movies" in the ForeignKey of Movie class