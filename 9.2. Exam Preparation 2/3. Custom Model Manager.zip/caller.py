import os
import django

from populate_db import populate_model_with_data

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Profile, Product, Order

# Import your models here
# Create and run your queries within functions

# populate_model_with_data(Profile)
# populate_model_with_data(Product)
# populate_model_with_data(Order)


print(Profile.objects.get_regular_customers())